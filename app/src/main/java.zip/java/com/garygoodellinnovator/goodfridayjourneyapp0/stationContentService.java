package com.garygoodellinnovator.goodfridayjourneyapp0;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class stationContentService extends Service {
    public stationContentService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
